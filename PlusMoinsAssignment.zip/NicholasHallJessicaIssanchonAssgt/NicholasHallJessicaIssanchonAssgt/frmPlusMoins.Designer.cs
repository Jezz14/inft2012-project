﻿namespace NicholasHallJessicaIssanchonAssgt
{
    partial class frmPlusMoins
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPlusMoins));
            this.btnPlayAgain = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnRoll = new System.Windows.Forms.Button();
            this.btnEndRoll = new System.Windows.Forms.Button();
            this.pbxDice1 = new System.Windows.Forms.PictureBox();
            this.txtbxScoreP1 = new System.Windows.Forms.RichTextBox();
            this.pbxDice5 = new System.Windows.Forms.PictureBox();
            this.pbxDice3 = new System.Windows.Forms.PictureBox();
            this.pbxDice4 = new System.Windows.Forms.PictureBox();
            this.pbxDice2 = new System.Windows.Forms.PictureBox();
            this.pbxDiceShow1 = new System.Windows.Forms.PictureBox();
            this.pbxDiceShow2 = new System.Windows.Forms.PictureBox();
            this.pbxDiceShow3 = new System.Windows.Forms.PictureBox();
            this.pbxDiceShow4 = new System.Windows.Forms.PictureBox();
            this.pbxDiceShow5 = new System.Windows.Forms.PictureBox();
            this.pbxDice6 = new System.Windows.Forms.PictureBox();
            this.chkbxHold1 = new System.Windows.Forms.CheckBox();
            this.chkbxHold2 = new System.Windows.Forms.CheckBox();
            this.chkbxHold5 = new System.Windows.Forms.CheckBox();
            this.chkbxHold3 = new System.Windows.Forms.CheckBox();
            this.chkbxHold4 = new System.Windows.Forms.CheckBox();
            this.txtbxGoal = new System.Windows.Forms.TextBox();
            this.lblGoal = new System.Windows.Forms.Label();
            this.txtbxScoreP2 = new System.Windows.Forms.RichTextBox();
            this.lblP1Score = new System.Windows.Forms.Label();
            this.lblP2Score = new System.Windows.Forms.Label();
            this.lblWarning = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice6)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPlayAgain
            // 
            this.btnPlayAgain.Location = new System.Drawing.Point(23, 583);
            this.btnPlayAgain.Name = "btnPlayAgain";
            this.btnPlayAgain.Size = new System.Drawing.Size(100, 40);
            this.btnPlayAgain.TabIndex = 0;
            this.btnPlayAgain.Text = "Play Again";
            this.btnPlayAgain.UseVisualStyleBackColor = true;
            this.btnPlayAgain.Click += new System.EventHandler(this.btnPlayAgain_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(871, 583);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(100, 40);
            this.btnQuit.TabIndex = 1;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnRoll
            // 
            this.btnRoll.Enabled = false;
            this.btnRoll.Location = new System.Drawing.Point(689, 104);
            this.btnRoll.Name = "btnRoll";
            this.btnRoll.Size = new System.Drawing.Size(120, 50);
            this.btnRoll.TabIndex = 2;
            this.btnRoll.Text = "Roll Dice";
            this.btnRoll.UseVisualStyleBackColor = true;
            this.btnRoll.Click += new System.EventHandler(this.btnRoll_Click);
            // 
            // btnEndRoll
            // 
            this.btnEndRoll.Location = new System.Drawing.Point(689, 426);
            this.btnEndRoll.Name = "btnEndRoll";
            this.btnEndRoll.Size = new System.Drawing.Size(120, 50);
            this.btnEndRoll.TabIndex = 3;
            this.btnEndRoll.Text = "End Roll";
            this.btnEndRoll.UseVisualStyleBackColor = true;
            this.btnEndRoll.Click += new System.EventHandler(this.btnEndRoll_Click);
            // 
            // pbxDice1
            // 
            this.pbxDice1.Image = ((System.Drawing.Image)(resources.GetObject("pbxDice1.Image")));
            this.pbxDice1.Location = new System.Drawing.Point(289, 583);
            this.pbxDice1.Name = "pbxDice1";
            this.pbxDice1.Size = new System.Drawing.Size(50, 50);
            this.pbxDice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDice1.TabIndex = 6;
            this.pbxDice1.TabStop = false;
            // 
            // txtbxScoreP1
            // 
            this.txtbxScoreP1.BackColor = System.Drawing.Color.White;
            this.txtbxScoreP1.Location = new System.Drawing.Point(524, 51);
            this.txtbxScoreP1.Name = "txtbxScoreP1";
            this.txtbxScoreP1.Size = new System.Drawing.Size(100, 495);
            this.txtbxScoreP1.TabIndex = 9;
            this.txtbxScoreP1.Text = "";
            // 
            // pbxDice5
            // 
            this.pbxDice5.Image = ((System.Drawing.Image)(resources.GetObject("pbxDice5.Image")));
            this.pbxDice5.Location = new System.Drawing.Point(601, 583);
            this.pbxDice5.Name = "pbxDice5";
            this.pbxDice5.Size = new System.Drawing.Size(50, 50);
            this.pbxDice5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDice5.TabIndex = 10;
            this.pbxDice5.TabStop = false;
            // 
            // pbxDice3
            // 
            this.pbxDice3.Image = ((System.Drawing.Image)(resources.GetObject("pbxDice3.Image")));
            this.pbxDice3.Location = new System.Drawing.Point(443, 583);
            this.pbxDice3.Name = "pbxDice3";
            this.pbxDice3.Size = new System.Drawing.Size(50, 50);
            this.pbxDice3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDice3.TabIndex = 11;
            this.pbxDice3.TabStop = false;
            // 
            // pbxDice4
            // 
            this.pbxDice4.Image = ((System.Drawing.Image)(resources.GetObject("pbxDice4.Image")));
            this.pbxDice4.Location = new System.Drawing.Point(520, 583);
            this.pbxDice4.Name = "pbxDice4";
            this.pbxDice4.Size = new System.Drawing.Size(50, 50);
            this.pbxDice4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDice4.TabIndex = 12;
            this.pbxDice4.TabStop = false;
            // 
            // pbxDice2
            // 
            this.pbxDice2.Image = ((System.Drawing.Image)(resources.GetObject("pbxDice2.Image")));
            this.pbxDice2.Location = new System.Drawing.Point(365, 583);
            this.pbxDice2.Name = "pbxDice2";
            this.pbxDice2.Size = new System.Drawing.Size(50, 50);
            this.pbxDice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDice2.TabIndex = 13;
            this.pbxDice2.TabStop = false;
            // 
            // pbxDiceShow1
            // 
            this.pbxDiceShow1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbxDiceShow1.Location = new System.Drawing.Point(20, 54);
            this.pbxDiceShow1.Name = "pbxDiceShow1";
            this.pbxDiceShow1.Size = new System.Drawing.Size(100, 100);
            this.pbxDiceShow1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDiceShow1.TabIndex = 14;
            this.pbxDiceShow1.TabStop = false;
            // 
            // pbxDiceShow2
            // 
            this.pbxDiceShow2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbxDiceShow2.Location = new System.Drawing.Point(341, 54);
            this.pbxDiceShow2.Name = "pbxDiceShow2";
            this.pbxDiceShow2.Size = new System.Drawing.Size(100, 100);
            this.pbxDiceShow2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDiceShow2.TabIndex = 15;
            this.pbxDiceShow2.TabStop = false;
            // 
            // pbxDiceShow3
            // 
            this.pbxDiceShow3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbxDiceShow3.Location = new System.Drawing.Point(20, 353);
            this.pbxDiceShow3.Name = "pbxDiceShow3";
            this.pbxDiceShow3.Size = new System.Drawing.Size(100, 100);
            this.pbxDiceShow3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDiceShow3.TabIndex = 16;
            this.pbxDiceShow3.TabStop = false;
            // 
            // pbxDiceShow4
            // 
            this.pbxDiceShow4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbxDiceShow4.Location = new System.Drawing.Point(341, 353);
            this.pbxDiceShow4.Name = "pbxDiceShow4";
            this.pbxDiceShow4.Size = new System.Drawing.Size(100, 100);
            this.pbxDiceShow4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDiceShow4.TabIndex = 17;
            this.pbxDiceShow4.TabStop = false;
            // 
            // pbxDiceShow5
            // 
            this.pbxDiceShow5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbxDiceShow5.Location = new System.Drawing.Point(181, 208);
            this.pbxDiceShow5.Name = "pbxDiceShow5";
            this.pbxDiceShow5.Size = new System.Drawing.Size(100, 100);
            this.pbxDiceShow5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDiceShow5.TabIndex = 18;
            this.pbxDiceShow5.TabStop = false;
            // 
            // pbxDice6
            // 
            this.pbxDice6.Image = ((System.Drawing.Image)(resources.GetObject("pbxDice6.Image")));
            this.pbxDice6.Location = new System.Drawing.Point(675, 583);
            this.pbxDice6.Name = "pbxDice6";
            this.pbxDice6.Size = new System.Drawing.Size(50, 50);
            this.pbxDice6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxDice6.TabIndex = 19;
            this.pbxDice6.TabStop = false;
            // 
            // chkbxHold1
            // 
            this.chkbxHold1.AutoSize = true;
            this.chkbxHold1.Location = new System.Drawing.Point(20, 160);
            this.chkbxHold1.Name = "chkbxHold1";
            this.chkbxHold1.Size = new System.Drawing.Size(82, 17);
            this.chkbxHold1.TabIndex = 20;
            this.chkbxHold1.Text = "Hold Dice 1";
            this.chkbxHold1.UseVisualStyleBackColor = true;
            // 
            // chkbxHold2
            // 
            this.chkbxHold2.AutoSize = true;
            this.chkbxHold2.Location = new System.Drawing.Point(344, 160);
            this.chkbxHold2.Name = "chkbxHold2";
            this.chkbxHold2.Size = new System.Drawing.Size(82, 17);
            this.chkbxHold2.TabIndex = 21;
            this.chkbxHold2.Text = "Hold Dice 2";
            this.chkbxHold2.UseVisualStyleBackColor = true;
            // 
            // chkbxHold5
            // 
            this.chkbxHold5.AutoSize = true;
            this.chkbxHold5.Location = new System.Drawing.Point(181, 314);
            this.chkbxHold5.Name = "chkbxHold5";
            this.chkbxHold5.Size = new System.Drawing.Size(82, 17);
            this.chkbxHold5.TabIndex = 22;
            this.chkbxHold5.Text = "Hold Dice 5";
            this.chkbxHold5.UseVisualStyleBackColor = true;
            // 
            // chkbxHold3
            // 
            this.chkbxHold3.AutoSize = true;
            this.chkbxHold3.Location = new System.Drawing.Point(20, 459);
            this.chkbxHold3.Name = "chkbxHold3";
            this.chkbxHold3.Size = new System.Drawing.Size(82, 17);
            this.chkbxHold3.TabIndex = 23;
            this.chkbxHold3.Text = "Hold Dice 3";
            this.chkbxHold3.UseVisualStyleBackColor = true;
            // 
            // chkbxHold4
            // 
            this.chkbxHold4.AutoSize = true;
            this.chkbxHold4.Location = new System.Drawing.Point(341, 459);
            this.chkbxHold4.Name = "chkbxHold4";
            this.chkbxHold4.Size = new System.Drawing.Size(82, 17);
            this.chkbxHold4.TabIndex = 24;
            this.chkbxHold4.Text = "Hold Dice 4";
            this.chkbxHold4.UseVisualStyleBackColor = true;
            // 
            // txtbxGoal
            // 
            this.txtbxGoal.Location = new System.Drawing.Point(699, 299);
            this.txtbxGoal.Name = "txtbxGoal";
            this.txtbxGoal.Size = new System.Drawing.Size(93, 20);
            this.txtbxGoal.TabIndex = 25;
            // 
            // lblGoal
            // 
            this.lblGoal.AutoSize = true;
            this.lblGoal.Location = new System.Drawing.Point(672, 283);
            this.lblGoal.Name = "lblGoal";
            this.lblGoal.Size = new System.Drawing.Size(150, 13);
            this.lblGoal.TabIndex = 26;
            this.lblGoal.Text = "Please Enter Goal Score <=50";
            // 
            // txtbxScoreP2
            // 
            this.txtbxScoreP2.Location = new System.Drawing.Point(873, 54);
            this.txtbxScoreP2.Name = "txtbxScoreP2";
            this.txtbxScoreP2.Size = new System.Drawing.Size(99, 495);
            this.txtbxScoreP2.TabIndex = 29;
            this.txtbxScoreP2.Text = "";
            // 
            // lblP1Score
            // 
            this.lblP1Score.Location = new System.Drawing.Point(531, 35);
            this.lblP1Score.Name = "lblP1Score";
            this.lblP1Score.Size = new System.Drawing.Size(78, 13);
            this.lblP1Score.TabIndex = 30;
            this.lblP1Score.Text = "Player 1 Score";
            // 
            // lblP2Score
            // 
            this.lblP2Score.Location = new System.Drawing.Point(886, 35);
            this.lblP2Score.Name = "lblP2Score";
            this.lblP2Score.Size = new System.Drawing.Size(85, 16);
            this.lblP2Score.TabIndex = 31;
            this.lblP2Score.Text = "Player 2 Score";
            // 
            // lblWarning
            // 
            this.lblWarning.AutoSize = true;
            this.lblWarning.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarning.ForeColor = System.Drawing.Color.Red;
            this.lblWarning.Location = new System.Drawing.Point(672, 229);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(160, 32);
            this.lblWarning.TabIndex = 36;
            this.lblWarning.Text = "You must enter a Goal\r\n     before starting!!";
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(718, 325);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(54, 23);
            this.btnEnter.TabIndex = 37;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // frmPlusMoins
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(984, 641);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.lblWarning);
            this.Controls.Add(this.lblP2Score);
            this.Controls.Add(this.lblP1Score);
            this.Controls.Add(this.txtbxScoreP2);
            this.Controls.Add(this.lblGoal);
            this.Controls.Add(this.txtbxGoal);
            this.Controls.Add(this.chkbxHold4);
            this.Controls.Add(this.chkbxHold3);
            this.Controls.Add(this.chkbxHold5);
            this.Controls.Add(this.chkbxHold2);
            this.Controls.Add(this.chkbxHold1);
            this.Controls.Add(this.pbxDice6);
            this.Controls.Add(this.pbxDiceShow5);
            this.Controls.Add(this.pbxDiceShow4);
            this.Controls.Add(this.pbxDiceShow3);
            this.Controls.Add(this.pbxDiceShow2);
            this.Controls.Add(this.pbxDiceShow1);
            this.Controls.Add(this.pbxDice2);
            this.Controls.Add(this.pbxDice4);
            this.Controls.Add(this.pbxDice3);
            this.Controls.Add(this.pbxDice5);
            this.Controls.Add(this.txtbxScoreP1);
            this.Controls.Add(this.pbxDice1);
            this.Controls.Add(this.btnEndRoll);
            this.Controls.Add(this.btnRoll);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnPlayAgain);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1000, 680);
            this.MinimumSize = new System.Drawing.Size(1000, 680);
            this.Name = "frmPlusMoins";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Death Dice";
            this.Load += new System.EventHandler(this.frmPlusMoins_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDiceShow5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDice6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPlayAgain;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnRoll;
        private System.Windows.Forms.Button btnEndRoll;
        private System.Windows.Forms.PictureBox pbxDice1;
        private System.Windows.Forms.RichTextBox txtbxScoreP1;
        private System.Windows.Forms.PictureBox pbxDice5;
        private System.Windows.Forms.PictureBox pbxDice3;
        private System.Windows.Forms.PictureBox pbxDice4;
        private System.Windows.Forms.PictureBox pbxDice2;
        private System.Windows.Forms.PictureBox pbxDiceShow1;
        private System.Windows.Forms.PictureBox pbxDiceShow2;
        private System.Windows.Forms.PictureBox pbxDiceShow3;
        private System.Windows.Forms.PictureBox pbxDiceShow4;
        private System.Windows.Forms.PictureBox pbxDiceShow5;
        private System.Windows.Forms.PictureBox pbxDice6;
        private System.Windows.Forms.CheckBox chkbxHold1;
        private System.Windows.Forms.CheckBox chkbxHold2;
        private System.Windows.Forms.CheckBox chkbxHold5;
        private System.Windows.Forms.CheckBox chkbxHold3;
        private System.Windows.Forms.CheckBox chkbxHold4;
        private System.Windows.Forms.TextBox txtbxGoal;
        private System.Windows.Forms.Label lblGoal;
        private System.Windows.Forms.RichTextBox txtbxScoreP2;
        private System.Windows.Forms.Label lblP1Score;
        private System.Windows.Forms.Label lblP2Score;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.Button btnEnter;
    }
}

