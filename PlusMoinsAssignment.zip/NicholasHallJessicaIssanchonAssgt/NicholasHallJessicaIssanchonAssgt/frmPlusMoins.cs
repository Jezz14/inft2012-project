﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NicholasHallJessicaIssanchonAssgt
{
    public partial class frmPlusMoins : Form
    {
      
        public frmPlusMoins()
        
        {
            InitializeComponent();
            

        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnPlayAgain_Click(object sender, EventArgs e)
        {
            pbxDiceShow1.Image = null;
            pbxDiceShow2.Image = null;
            pbxDiceShow3.Image = null;
            pbxDiceShow4.Image = null;
            pbxDiceShow5.Image = null;
            chkbxHold1.Checked = false;
            chkbxHold2.Checked = false;
            chkbxHold3.Checked = false;
            chkbxHold4.Checked = false;
            chkbxHold5.Checked = false;
            txtbxGoal.ReadOnly = false;
            txtbxScoreP1.Text = "";
            txtbxScoreP2.Text = "";
            txtbxGoal.Text = "";
            btnRoll.Enabled = false;
        }

        private void btnRoll_Click(object sender, EventArgs e)
        {
            RollDice();
        }

      
        private void RollDice()
        {

            string sGoal = Convert.ToString(txtbxGoal.Text);
            txtbxScoreP1.Text = "Goal score =  " + sGoal;
            txtbxScoreP2.Text = "Goal score =  " + sGoal;
            txtbxGoal.ReadOnly = true;
            Random r = new Random();

                int iRnd = new int();


            if (!chkbxHold1.Checked)
            { 
                iRnd = r.Next(0, 6);

                if (iRnd == 0)
                    pbxDiceShow1.Image = pbxDice1.Image;
                else if (iRnd == 1)
                    pbxDiceShow1.Image = pbxDice2.Image;
                else if (iRnd == 2)
                    pbxDiceShow1.Image = pbxDice3.Image;
                else if (iRnd == 3)
                    pbxDiceShow1.Image = pbxDice4.Image;
                else if (iRnd == 4)
                    pbxDiceShow1.Image = pbxDice5.Image;
                else
                    pbxDiceShow1.Image = pbxDice6.Image;}


            if (!chkbxHold2.Checked)
            {
                iRnd = r.Next(0, 6);

                if (iRnd == 0)
                    pbxDiceShow2.Image = pbxDice1.Image;
                else if (iRnd == 1)
                    pbxDiceShow2.Image = pbxDice2.Image;
                else if (iRnd == 2)
                    pbxDiceShow2.Image = pbxDice3.Image;
                else if (iRnd == 3)
                    pbxDiceShow2.Image = pbxDice4.Image;
                else if (iRnd == 4)
                    pbxDiceShow2.Image = pbxDice5.Image;
                else
                    pbxDiceShow2.Image = pbxDice6.Image;
            }



            if (!chkbxHold3.Checked)
            {
                iRnd = r.Next(0, 6);

                if (iRnd == 0)
                    pbxDiceShow3.Image = pbxDice1.Image;
                else if (iRnd == 1)
                    pbxDiceShow3.Image = pbxDice2.Image;
                else if (iRnd == 2)
                    pbxDiceShow3.Image = pbxDice3.Image;
                else if (iRnd == 3)
                    pbxDiceShow3.Image = pbxDice4.Image;
                else if (iRnd == 4)
                    pbxDiceShow3.Image = pbxDice5.Image;
                else
                    pbxDiceShow3.Image = pbxDice6.Image;
            }


            if (!chkbxHold4.Checked)
            {
                iRnd = r.Next(0, 6);

                if (iRnd == 0)
                    pbxDiceShow4.Image = pbxDice1.Image;
                else if (iRnd == 1)
                    pbxDiceShow4.Image = pbxDice2.Image;
                else if (iRnd == 2)
                    pbxDiceShow4.Image = pbxDice3.Image;
                else if (iRnd == 3)
                    pbxDiceShow4.Image = pbxDice4.Image;
                else if (iRnd == 4)
                    pbxDiceShow4.Image = pbxDice5.Image;
                else
                    pbxDiceShow4.Image = pbxDice6.Image;
            }



            if (!chkbxHold5.Checked)
            {
                iRnd = r.Next(0, 6);

                if (iRnd == 0)
                    pbxDiceShow5.Image = pbxDice1.Image;
                else if (iRnd == 1)
                    pbxDiceShow5.Image = pbxDice2.Image;
                else if (iRnd == 2)
                    pbxDiceShow5.Image = pbxDice3.Image;
                else if (iRnd == 3)
                    pbxDiceShow5.Image = pbxDice4.Image;
                else if (iRnd == 4)
                    pbxDiceShow5.Image = pbxDice5.Image;
                else
                    pbxDiceShow5.Image = pbxDice6.Image;

            }
            chkbxHold1.Enabled = true;
            chkbxHold2.Enabled = true;
            chkbxHold3.Enabled = true;
            chkbxHold4.Enabled = true;
            chkbxHold5.Enabled = true;

        }

        private void btnEndRoll_Click(object sender, EventArgs e)
        {
            pbxDiceShow1.Image = null;
            pbxDiceShow2.Image = null;
            pbxDiceShow3.Image = null;
            pbxDiceShow4.Image = null;
            pbxDiceShow5.Image = null;
            chkbxHold1.Checked = false;
            chkbxHold2.Checked = false;
            chkbxHold3.Checked = false;
            chkbxHold4.Checked = false;
            chkbxHold5.Checked = false;
            txtbxGoal.ReadOnly = false;
            btnRoll.Enabled = true;
            chkbxHold1.Enabled = false;
            chkbxHold2.Enabled = false;
            chkbxHold3.Enabled = false;
            chkbxHold4.Enabled = false;
            chkbxHold5.Enabled = false;
            txtbxGoal.ReadOnly = false;

        
        }

      

        private void btnEnter_Click(object sender, EventArgs e)
        {
            int iTempInteger;
            int goalScore;
            bool isNumeric;

            isNumeric = int.TryParse(txtbxGoal.Text, out iTempInteger);

            if (isNumeric == false)
            { MessageBox.Show("Please Enter a valid Number!"); }

            goalScore = int.Parse(txtbxGoal.Text);
            if (goalScore > 50)
            { MessageBox.Show("Please enter a number below 50!");
            }

           
            if (txtbxGoal.Text == "" || !isNumeric || goalScore > 50)
                btnRoll.Enabled = false;
            else
                btnRoll.Enabled = true;
        
        }
        


        private void frmPlusMoins_Load(object sender, EventArgs e)
        {
           
            chkbxHold1.Enabled = false;
            chkbxHold2.Enabled = false;
            chkbxHold3.Enabled = false;
            chkbxHold4.Enabled = false;
            chkbxHold5.Enabled = false;
        }

    }
}
